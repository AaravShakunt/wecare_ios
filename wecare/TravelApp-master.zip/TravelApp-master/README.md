# Projet : Réalisez une application de voyage
## TravelApp

**Compétences évaluées**
-

- Faire des tests unitaires
- Effectuer des appels réseaux standards
- Faire une application avec plusieurs pages
- Présenter une alerte
- Gérer le clavier iOS

**Competencies evaluated**
-

- Conduct unit tests
- Perform standard network calls
- Make an application with several pages
- Submit an alert
- Manage the iOS keyboard

